#!/bin/bash

gcc -Wall main.c intelhex.c -o intelhex